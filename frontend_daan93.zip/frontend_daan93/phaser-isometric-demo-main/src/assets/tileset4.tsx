<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="tileset4" tilewidth="128" tileheight="144" tilecount="5" columns="5">
 <image source="tileset4.png" width="640" height="146"/>
</tileset>
