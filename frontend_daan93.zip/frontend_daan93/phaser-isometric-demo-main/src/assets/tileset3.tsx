<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="tileset3" tilewidth="128" tileheight="224" tilecount="10" columns="5">
 <image source="tileset3.png" width="640" height="448"/>
</tileset>
