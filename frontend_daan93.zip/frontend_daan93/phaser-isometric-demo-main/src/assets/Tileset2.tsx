<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="Tileset2" tilewidth="128" tileheight="192" tilecount="6" columns="3">
 <image source="tileset2.png" width="384" height="384"/>
</tileset>
