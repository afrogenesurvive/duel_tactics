<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="tileset2_2" tilewidth="128" tileheight="64" tilecount="6" columns="3">
 <image source="tileset2_2.png" width="384" height="128"/>
</tileset>
