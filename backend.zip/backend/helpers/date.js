exports.dateToString = date => new Date(date).toLocaleDateString();
